package com.example.ordinario;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ventas extends AppCompatActivity {
    Button btn7;
    private ListView listView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_venta);
        btn7 = (Button) findViewById(R.id.btn7);

        btn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Regresaste al inicio", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(i);
            }
        });
        listView=(ListView) findViewById(R.id.productos);
        String[] nombre={"blusa de vestir clásica.","blusa manga corta ","blusa negra","blusa de rayas"};
        String[] precio={"$150","$200","$308","$250"};
        String[] idpro={"23145","456","14785","2589"};
        Integer[] idimagen={R.drawable.img_6,R.drawable.img_5,R.drawable.img_4,R.drawable.img_3};
        adaptador adapter = new adaptador(this, nombre, precio, idpro, idimagen);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?>parent,View view, int position, long id){
                Toast.makeText(getApplicationContext(), "Seleccionaste el producto:"+nombre, Toast.LENGTH_LONG).show();
                Intent i = new Intent(getApplicationContext(),ticket.class);
                startActivity(i);
            }
        });
    }
}
